package br.unifor.cct.ads.ducksim.entity;

import br.unifor.cct.ads.ducksim.entity.Duck;

public class RubberDuck extends Duck {

    @Override
    public void display() {

        System.out.println("\n------------------------------");
        System.out.println("Displaying Rubber Duck!");
        swim();
        ///q.quack();
        f.fly();
        System.out.println("------------------------------\n");

    }

}
