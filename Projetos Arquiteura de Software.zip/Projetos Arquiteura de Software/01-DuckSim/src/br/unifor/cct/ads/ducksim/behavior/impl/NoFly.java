package br.unifor.cct.ads.ducksim.behavior.impl;

import br.unifor.cct.ads.ducksim.behavior.FlyBehavior;

public class NoFly implements FlyBehavior {

    @Override
    public void fly() {
        System.out.println("I not fly!!!!");
    }

}
