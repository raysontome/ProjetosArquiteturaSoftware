package br.unifor.cct.ads.ducksim.behavior;

public interface QuackBehavior {

    public void quack();

}
