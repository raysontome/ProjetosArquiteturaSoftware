package br.unifor.cct.ads.ducksim.entity;

import br.unifor.cct.ads.ducksim.entity.Duck;

public class MallardDuck extends Duck {

    @Override
    public void display() {
        System.out.println("\n+++++++++++++++++++++++++++++");
        System.out.println("Displaying Mallard Duck!");
        swim();
        ///q.quack();
        f.fly();
        System.out.println("+++++++++++++++++++++++++++++\n");
    }
}
