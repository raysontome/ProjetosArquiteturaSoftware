package br.unifor.cct.ads.ducksim.behavior.impl;

import br.unifor.cct.ads.ducksim.behavior.FlyBehavior;

public class FlyWithWing implements FlyBehavior {

    @Override
    public void fly() {
        System.out.println("aeouiauodjdasjias");

    }

}
