package br.unifor.cct.ads.ducksim.behavior;

public interface FlyBehavior {

    public void fly();

}
