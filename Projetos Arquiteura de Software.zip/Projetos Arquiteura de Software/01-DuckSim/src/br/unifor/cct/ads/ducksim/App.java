package br.unifor.cct.ads.ducksim;

import br.unifor.cct.ads.ducksim.behavior.impl.FlyWithWing;
import br.unifor.cct.ads.ducksim.behavior.impl.NoFly;
import br.unifor.cct.ads.ducksim.behavior.impl.RocketFly;
import br.unifor.cct.ads.ducksim.entity.MallardDuck;
import br.unifor.cct.ads.ducksim.entity.RedheadDuck;
import br.unifor.cct.ads.ducksim.entity.RubberDuck;
import br.unifor.cct.ads.ducksim.behavior.FlyBehavior;

public class App {

    public static void main(String[] args) {

        FlyBehavior noFly = new NoFly();
        FlyBehavior flywithWings = new FlyWithWing();
        FlyBehavior rocketFly = new RocketFly();

        RedheadDuck rhd = new RedheadDuck();
        rhd.setFly(flywithWings);

        MallardDuck md = new MallardDuck();
        md.setFly(flywithWings);

        RubberDuck rd = new RubberDuck();
        rd.setFly(rocketFly);

        rhd.display();
        md.display();
        rd.display();


    }

}
