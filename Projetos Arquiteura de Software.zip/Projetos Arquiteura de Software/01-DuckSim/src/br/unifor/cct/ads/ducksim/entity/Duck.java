package br.unifor.cct.ads.ducksim.entity;

import br.unifor.cct.ads.ducksim.behavior.FlyBehavior;
import br.unifor.cct.ads.ducksim.behavior.QuackBehavior;

public abstract class Duck {

    protected FlyBehavior f;

    protected QuackBehavior q;

    public void setFly(FlyBehavior fly) {
        this.f = fly;
    }

    public void setQuack(QuackBehavior quack) {
        this.q = quack;
    }

    public void swim(){
        System.out.println("I am swimming!");
    }

    public abstract void display();

}
