package br.unifor.cct.ads.ducksim.behavior.impl;

import br.unifor.cct.ads.ducksim.behavior.FlyBehavior;

public class RocketFly implements FlyBehavior{

    @Override
    public void fly() {
        System.out.println("Let's go to the moon!!!");
    }

}
