package br.unifor.cct.ads.observer;

import java.util.ArrayList;
import java.util.List;

public abstract class Subject {

    private List<Observer> observers;

    public Subject() {
        this.observers = new ArrayList<>();
    }

    public void addObserver(Observer o){
        this.observers.add(o);
    }

    public  void removeObserver(Observer o){
        this.observers.remove(o);
    }

    public void notifyAllObserver(double temperature, double humidity, double pressure){
        for (Observer observer: observers) {
            observer.notifyNewMeasuements(temperature, humidity, pressure);
        }
    }


}
