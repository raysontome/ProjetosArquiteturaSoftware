package br.unifor.cct.ads;

import br.unifor.cct.ads.observer.Subject;

public class Weather extends Subject {

    private double temperature;
    private double humidity;
    private double pressure;

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
        this.mesurementsChanged();
    }

    public double getHumidity() {
        return humidity;
    }

    public void setHumidity(double humidity) {
        this.humidity = humidity;
        this.mesurementsChanged();
    }

    public double getPressure() {
        return pressure;
    }

    public void setPressure(double pressure) {
        this.pressure = pressure;
        this.mesurementsChanged();
    }

    public void mesurementsChanged(){
        notifyAllObserver(temperature, humidity, pressure);
    }

}
