package br.unifor.cct.ads.display;

public interface Display {

    public void update();

}
