package br.unifor.cct.ads;

import br.unifor.cct.ads.display.impl.DefaultDisplay;
import br.unifor.cct.ads.display.impl.ImageDisplay;
import br.unifor.cct.ads.display.impl.StatsDisplay;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Weather weather = new Weather();

        DefaultDisplay defaultDisplay = new DefaultDisplay();
        StatsDisplay statsDisplay = new StatsDisplay();
        ImageDisplay imageDisplay = new ImageDisplay();

        Scanner scanner = new Scanner(System.in);

        while (true){

            System.out.print("#>");
            String line = scanner.nextLine();

            String[] aux = line.split(" ");

            switch (aux[0]){

                case "temp":
                    weather.setTemperature(Double.parseDouble(aux[1]));
                    break;

                case "humi":
                    weather.setHumidity(Double.parseDouble(aux[1]));
                    break;

                case "pres":
                    weather.setPressure(Double.parseDouble(aux[1]));
                    break;

                case "add":

                    switch (aux[1]){
                        case "display":
                            weather.addObserver(defaultDisplay);
                            break;

                        case "stats":
                            weather.addObserver(statsDisplay);
                            break;

                        case "image":
                            weather.addObserver(imageDisplay);
                            break;
                    }

                    break;

                case "del":

                    switch (aux[1]){
                        case "display":
                            weather.removeObserver(defaultDisplay);
                            break;

                        case "stats":
                            weather.removeObserver(statsDisplay);
                            break;

                        case "image":
                            weather.removeObserver(imageDisplay);
                            break;
                    }

                    break;

            }
            System.out.println();

        }



    }

}
