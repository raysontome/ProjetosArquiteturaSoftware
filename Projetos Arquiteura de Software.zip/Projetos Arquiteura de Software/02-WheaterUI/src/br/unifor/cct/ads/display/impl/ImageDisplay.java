package br.unifor.cct.ads.display.impl;

import br.unifor.cct.ads.display.Display;
import br.unifor.cct.ads.observer.Observer;

public class ImageDisplay implements Display, Observer {

    private double temperature;
    private double humidity;
    private double pressure;

    @Override
    public void update() {

        System.out.println("\n==============================");
        System.out.println("       Image Display");
        System.out.println("==============================");
        System.out.println("");
        if (pressure > 50){
            System.out.println("It's raining!");
        } else {
            System.out.println("It's sunning!");
        }
        System.out.println("==============================\n");

    }

    @Override
    public void notifyNewMeasuements(double temperature, double humidity, double pressure) {

        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;

        update();


    }

}
