package br.unifor.cct.ads.observer;

public interface Observer {

    public void notifyNewMeasuements(double temperature, double humidity, double pressure);

}
