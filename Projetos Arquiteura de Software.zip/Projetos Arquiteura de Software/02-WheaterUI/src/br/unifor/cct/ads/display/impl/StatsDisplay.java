package br.unifor.cct.ads.display.impl;

import br.unifor.cct.ads.display.Display;
import br.unifor.cct.ads.observer.Observer;

import java.util.ArrayList;
import java.util.List;

public class StatsDisplay implements Display, Observer {

    private List<Double> temperatures;

    public StatsDisplay() {
        this.temperatures = new ArrayList<>();
    }

    @Override
    public void update() {

        double averageTemperature = 0;
        for (Double temp : temperatures) {
            averageTemperature += temp;
        }
        averageTemperature = averageTemperature / temperatures.size();

        double minTemp = temperatures.get(0);
        for (int i = 1; i < temperatures.size(); i++) {
            if (temperatures.get(i - 1) < temperatures.get(i)) {
                minTemp = temperatures.get(i - 1);
            }
        }

        double maxTemp = temperatures.get(0);
        for (int i = 1; i < temperatures.size(); i++) {
            if (temperatures.get(i - 1) > temperatures.get(i)) {
                maxTemp = temperatures.get(i - 1);
            }
        }

        System.out.println("\n==============================");
        System.out.println("      Statistical Display");
        System.out.println("==============================");
        System.out.println("");
        System.out.println("Average temperature: " + averageTemperature);
        System.out.println("Min temperature: " + minTemp);
        System.out.println("Max temperature: " + maxTemp);
        System.out.println("==============================\n");

    }

    @Override
    public void notifyNewMeasuements(double temperature, double humidity, double pressure) {
        temperatures.add(temperature);
        update();
    }

}
